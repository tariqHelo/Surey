<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Downloads\Laravel-Faculty-RoomBooking-master\Laravel-Faculty-RoomBooking-master\resources\views/admin/bookings/search.blade.php ENDPATH**/ ?>