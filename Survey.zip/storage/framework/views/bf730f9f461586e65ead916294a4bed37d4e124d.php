<?php $__env->startSection('content'); ?>

<div class="col">
            <div class="">
                <a href="<?php echo e(route("admin.sections.index")); ?>">
                    <button  class="btn btn-lg btn-danger" >back to sections</button>
                </a>
                <a href="<?php echo e(url('file/'.$section->id )); ?>">
                    <button
                        class="btn btn-lg btn-primary">
                           update excel file
                    </button>
                </a>
                <a href="<?php echo e(url('/download/file/'.$section->title )); ?>">
                    <button
                       class="btn btn-lg btn-success">
                           download excel file
                    </button>
                </a>
            </div>

    <div class="card-body">
        <?php if(count($section->questionAnswers) > 0): ?>
            <div class="table table-striped">
                <table class="table">
                    <thead >
                    <tr>
                        <?php $keys = []; ?>
                        <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="thead-dark"><?php echo e($value->title); ?></th>
                        <?php array_push($keys , $value->title); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tr>
                    </thead>
                    <tbody class="px-12">
                        
                        <?php $__currentLoopData = $section->questionAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <?php $answers = json_decode($answer->value); ?>
                            <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                <td class="border px-12 py-2">
                                    <?php echo e($answers->{$key}); ?>

                                </td>
                                
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td class="border px-12 py-2">
                                    <a href="<?php echo e(route('admin.questionanswer.delete' , ['answer' => $answer->id ])); ?>" >
                                        <button onclick='return confirm("Are you sure??")' type="submit"
                                                class="hover:bg-red-700 text-white font-bold py-2 px-2 rounded-full">
                                            <img src="https://img.icons8.com/color/30/000000/delete-forever.png"/>
                                        </button>
                                    </a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-danger mx-5 my-5 border border-red-400 text-red-700 px-4 py-3 rounded relative "
                    role="alert">
                <strong class="font-bold">Opss !!</strong>
                <span class="block sm:inline">we havent any section to show here , you can create new section</span>
            </div>
        <?php endif; ?>
  </div>

</div>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Downloads\Laravel-Faculty-RoomBooking-master\Laravel-Faculty-RoomBooking-master\resources\views/admin/section/show.blade.php ENDPATH**/ ?>