<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.room.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.rooms.update", [$room->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.room.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $room->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.room.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="capacity"><?php echo e(trans('cruds.room.fields.capacity')); ?></label>
                <input class="form-control <?php echo e($errors->has('capacity') ? 'is-invalid' : ''); ?>" type="number" name="capacity" id="capacity" value="<?php echo e(old('capacity', $room->capacity)); ?>" step="1">
                <?php if($errors->has('capacity')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('capacity')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.room.fields.capacity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.room.fields.description')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo e(old('description', $room->description)); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.room.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="hourly_rate"><?php echo e(trans('cruds.room.fields.hourly_rate')); ?></label>
                <input class="form-control <?php echo e($errors->has('hourly_rate') ? 'is-invalid' : ''); ?>" type="number" name="hourly_rate" id="hourly_rate" value="<?php echo e(old('hourly_rate', $room->hourly_rate)); ?>" step="0.01">
                <?php if($errors->has('hourly_rate')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('hourly_rate')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.room.fields.hourly_rate_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Downloads\Laravel-Faculty-RoomBooking-master\Laravel-Faculty-RoomBooking-master\resources\views/admin/rooms/edit.blade.php ENDPATH**/ ?>