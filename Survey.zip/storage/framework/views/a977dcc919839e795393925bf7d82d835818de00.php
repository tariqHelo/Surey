<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
            <a class="btn btn-dark" href="<?php echo e(route('admin.section.edit' , ['section' => $section->id])); ?>">
                الرجوع للقسم
            </a>
        </div>
    </div>
    <div class="container">
        
        <div class="row mt-5">
            <div class="col-12 offset-2 mt-8">
                <div class="card">
                    <div class="card-header bg-info">
                        <h3 class="text-white">تعديل السؤال</h3>
                    </div>
                    <div class="card-body">
                    
                       <form method="POST" action="<?php echo e(route('admin.question.update' , ['section' => $section->id , 'question' => $question->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                            <div class="form-group">
                                <label>عنوان السؤال:</label>
                                <input type="text" name="title"  value="<?php echo e(old('title')?? $question->title); ?>"
                                 class="form-control" placeholder="عنوان السؤال">
                            </div>
                   
                            <div class="form-group">
                                <label>نوع السؤال:</label>
                                 <select class="form-control" name="feild_type_id" id="exampleFormControlSelect1">
                                    <?php $__currentLoopData = $feild_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($type->id); ?>"><?php echo e($type->type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                   
                            <div class="form-group text-center">
                                <button class="btn btn-success btn-submit">حفظ</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Downloads\Laravel-Faculty-RoomBooking-master\Laravel-Faculty-RoomBooking-master\resources\views/admin/question/edit.blade.php ENDPATH**/ ?>