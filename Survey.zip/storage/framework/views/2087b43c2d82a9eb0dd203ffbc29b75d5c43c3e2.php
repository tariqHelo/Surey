<?php $__env->startSection('content'); ?>
<h3 class="page-title"><?php echo e(trans('global.systemCalendar')); ?></h3>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.systemCalendar')); ?>

    </div>

    <div class="card-body">
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css' />
        <form>
            <div class="row">
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="room_id">Room</label>
                        <select class="form-control select2" name="room_id" id="room_id">
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(request()->input('room_id') == $id ? 'selected' : ''); ?>><?php echo e($room); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="user_id">User</label>
                        <select class="form-control select2" name="user_id" id="user_id">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(request()->input('user_id') == $id ? 'selected' : ''); ?>><?php echo e($user); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary mt-4">
                        Filter
                    </button>
                </div>
            </div>
        </form>

        <div id='calendar'></div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js'></script>
<script>
    $(document).ready(function () {
            // page is now ready, initialize the calendar...
            events=<?php echo json_encode($events); ?>;
            $('#calendar').fullCalendar({
                // put your options and callbacks here
                events: events,


            })
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\Downloads\Laravel-Faculty-RoomBooking-master\Laravel-Faculty-RoomBooking-master\resources\views/admin/calendar/calendar.blade.php ENDPATH**/ ?>