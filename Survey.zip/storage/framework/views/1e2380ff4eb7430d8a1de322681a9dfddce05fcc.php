<?php $__env->startSection('content'); ?>
 <div style="margin-bottom: 10px;" class="row">
        
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_section')): ?>
        <div class="card-header">
             <a class="btn btn-success" href="<?php echo e(route("admin.section-create")); ?>">
                إضافة قسم جديد
            </a>
        </div>
    <?php endif; ?>
 <div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-User">
                <thead>
                    <tr>
                        <th class="px-2 py-2">Title</th>
                        <th class="px-2 py-2"style="width: 10%">Create At</th>
                        <th class="px-2 py-2"style="width: 6%">Closed At</th>
                        <th class="px-2 py-2"style="width: 4%">Count</th>
                        <th class="px-2 py-2">Link</th>
                        <th class="" style="width: 15%">Action </th>
                    </tr>
                </thead>
                <tbody>
               <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border px-4 py-2"><?php echo e($section->title); ?></td>
                                    <td class="border px-4 py-2"><?php echo e($section->created_at); ?></td>
                                    <td class="border px-4 py-2"><?php echo e($section->closed_at ?? "active"); ?></td>
                                    <td class="border px-4 py-2"><?php echo e(count($section->questionAnswers)); ?></td>
                                    <td class="border text-blue-700 px-4 py-2"><a href="<?php echo e(route('admin.questionnaire.show' , ['section' => $section->title])); ?>" target="_blank"><?php echo e(route('admin.questionnaire.show' , ['section' => $section->title])); ?></a></td>
                                    <td class="border px-3 py-2">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_section')): ?>
                                            <a href="<?php echo e(route('admin.section.edit' , ['section' => $section->id])); ?>">
                                            <button

                                                    class="hover:bg-green-700 text-white font-bold py-2 px-2 rounded-full">
                                                <img src="https://img.icons8.com/dusk/30/000000/change.png"/>
                                            </button>
                                            </a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_section')): ?>
                                            <a href="<?php echo e(route('admin.section.delete' , ['section' => $section->id])); ?>">
                                                <button onclick='return confirm("Are you sure??")' type="submit"
                                                        class="hover:bg-red-700 text-white font-bold py-2 px-3 rounded-full">
                                                    <img src="https://img.icons8.com/color/30/000000/delete-forever.png"/>
                                                </button>
                                            </a> 
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_data')): ?>
                                            <a href="<?php echo e(route('admin.section.show' , ['section' => $section->id])); ?>">
                                                <button
                                                        class="hover:bg-gray-700 text-white font-bold py-2 px-3 rounded-full">
                                                    <img src="https://img.icons8.com/dusk/30/000000/survey.png"/>

                                                </button>
                                            </a>
                                        <?php endif; ?>
                                           
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel-Faculty-Survey\resources\views/admin/section/sections.blade.php ENDPATH**/ ?>