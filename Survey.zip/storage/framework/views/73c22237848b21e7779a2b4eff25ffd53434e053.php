<?php $__env->startSection('content'); ?>

     
    <div class="card-header">
       <a class="btn btn-success" href="<?php echo e(route("admin.sections.index")); ?>">
                الرجوع للإقسام 
        </a>
         <a href="<?php echo e(route('admin.section.status' , ['section' => $section->id] )); ?>">
            
            <button 
              class="bg-<?php echo e($section->closed_at == null ? "red" : "green"); ?>

              -500 hover:bg-<?php echo e($section->closed_at == null ? "red" : "green"); ?>

              -700 text-white font-bold btn btn-outline-primary rounded-full">
                 <?php echo e($section->closed_at == null ? __('إيقاف') : __('تشغيل')); ?>

             </button>
       </a>
    </div>
    
    <div class="card-header">
    
        <form method="POST" action="<?php echo e(route('admin.section.update' , ['section' => $section->id])); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="title">إسم القسم</label>
                <input class="form-control" type="text" name="title" id="title"
                 value="<?php echo e(old('title')?? $section->title); ?>">
               
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    حفظ
                </button>
            </div>
        </form>
    </div>
</div>

     <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
         
        </div>
    </div>
    

<div class="card-body">
     <div class="card-header">
      <a class="btn btn-primary" href="<?php echo e(route('admin.question.create' , ['section' => $section->id])); ?>">
               إضافة سؤال
            </a>
    </div>
        <div class="table-responsive mt-2">
            <table class=" table table-bordered table-striped table-hover datatable datatable-User">
                 <thead class="thead-dark">
                    <tr>
                       <th class=" px-4 py-2">Title</th>
                        <th class="px-4 py-2">Create At</th>
                        <th class="px-4 py-2">Feild Type</th>
                        <th class="px-4 py-2"></th>
                    </tr>
                 </thead>
            
                <tbody>
                   <?php $__currentLoopData = $section->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="border px-12 py-2"><?php echo e($question->title); ?></td>
                                    <td class="border px-12 py-2"><?php echo e($question->created_at); ?></td>
                                    <td class="border px-12 py-2"><?php echo e($question->feialdType->type); ?></td>
                                    <td class="border px-3 py-2">
                                        <a href="<?php echo e(route('admin.question.edit' , ['section' => $section->id , 'question' => $question->id ])); ?>">
                                            <button
                                                    class="hover:bg-green-700 text-white font-bold py-2 px-2 rounded-full">
                                                <img src="https://img.icons8.com/dusk/30/000000/change.png"/>
                                            </button>
                                        </a>
                                        <a href="<?php echo e(route('admin.question.delete' , ['section' => $section->id , 'question' => $question->id ])); ?>" >
                                            <button onclick='return confirm("Are you sure??")' type="submit"
                                                    class="hover:bg-red-700 text-white font-bold py-2 px-2 rounded-full">
                                                <img src="https://img.icons8.com/color/30/000000/delete-forever.png"/>
                                            </button>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Laravel-Faculty-Survey\resources\views/admin/section/edit.blade.php ENDPATH**/ ?>