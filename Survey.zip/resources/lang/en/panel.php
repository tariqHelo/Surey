<?php

return [
    'site_title' => 'Faculty',
];
